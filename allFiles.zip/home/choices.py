ANREDE_CHOICES = (
    (1, "Herr"),
    (2, "Frau"),
    (3, "—")
)

STIMMFACH_CHOICES = (
    (1, "Sopran"),
    (2, "Alt"),
    (3, "Tenor"),
    (4, "Bass"),
    (5, "—")
)
